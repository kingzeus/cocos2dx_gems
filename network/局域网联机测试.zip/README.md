我使用的是cocos2d-x 3.2版本
Classes，proj.android和proj.ios_mac直接覆盖一个新的工程，然后编译即可。
android工程已在魅族MX2机型上测试过，没有问题。
这只是一个简单的通信测试，如果需要以它为基本，可能还需要添加一些基础性功能，请自行解决。
										by 若尘