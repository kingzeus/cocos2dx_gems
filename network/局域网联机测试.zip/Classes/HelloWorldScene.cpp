#include "HelloWorldScene.h"
//#include "MySocket.h"
#include "ODSocket.h"
#include <thread>

USING_NS_CC;
using namespace std;

#define MCAST_PORT    8888
#define MCAST_ADDR    "224.0.0.88"          /*一个局部连接多播地址，路由器不进行转发*/
#define MCAST_DATA    "9:BROADCAST TEST DATA aha" /*多播发送的数据*/
#define MCAST_INTERVAL 5                    /*发送间隔时间*/
#define BUFF_SIZE     256
Scene* HelloWorld::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }
    
    Size visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    /////////////////////////////
    // 2. add a menu item with "X" image, which is clicked to quit the program
    //    you may modify it.

    // add a "close" icon to exit the progress. it's an autorelease object
    auto closeItem = MenuItemImage::create(
                                           "CloseNormal.png",
                                           "CloseSelected.png",
                                           CC_CALLBACK_1(HelloWorld::menuCloseCallback, this));
    
	closeItem->setPosition(Vec2(origin.x + visibleSize.width - closeItem->getContentSize().width/2 ,
                                origin.y + closeItem->getContentSize().height/2));

    // create menu, it's an autorelease object
    auto menu = Menu::create(closeItem, NULL);
    menu->setPosition(Vec2::ZERO);
    this->addChild(menu, 1);

    /////////////////////////////
    // 3. add your codes below...

    // add a label shows "Hello World"
    // create and initialize a label
    
    auto label = LabelTTF::create("Hello World", "Arial", 24);
    
    // position the label on the center of the screen
    label->setPosition(Vec2(origin.x + visibleSize.width/2,
                            origin.y + visibleSize.height - label->getContentSize().height));

    // add the label as a child to this layer
    this->addChild(label, 1);

    // add "HelloWorld" splash screen"
    auto sprite = Sprite::create("HelloWorld.png");

    // position the sprite on the center of the screen
    sprite->setPosition(Vec2(visibleSize.width/2 + origin.x, visibleSize.height/2 + origin.y));

    // add the sprite as a child to this layer
    this->addChild(sprite, 0);
    
    MenuItemFont *server = MenuItemFont::create("server", CC_CALLBACK_0(HelloWorld::server, this));
    MenuItemFont *client = MenuItemFont::create("新建房间",[&](Ref* sender){
        log("新建房间");
        std::thread t1(&HelloWorld::client,this);
        t1.detach();
    });
    MenuItemFont *test = MenuItemFont::create("test", [&](Ref* sender){
        log("test");
        client_fd.Send("server send to test!", 256);
    });

    
    Menu *socketMenu = Menu::create(server,client,test, NULL);
    socketMenu->setPosition(400,200);
    socketMenu->alignItemsVertically();
    addChild(socketMenu);
    
    aaa = false;
    std::thread t2(&HelloWorld::server,this);
    t2.detach();
//    std::thread t1(&HelloWorld::client,this);
//    t1.detach();
    
    
    schedule(schedule_selector(HelloWorld::logic), 0.5f);
    
    log("in major thread");
    
    
    
    return true;
}

void HelloWorld::logic(float dt){
    if (getChildByTag(11)==NULL&&aaa) {
        addRoomJoin();
    }
}

void HelloWorld::menuCloseCallback(Ref* pSender)
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WP8) || (CC_TARGET_PLATFORM == CC_PLATFORM_WINRT)
	MessageBox("You pressed the close button. Windows Store Apps do not implement a close button.","Alert");
    return;
#endif

    Director::getInstance()->end();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    exit(0);
#endif
}

void HelloWorld::server(){
    log("server");
    
    ODSocket socket;
    socket.Init();
    socket.UdpCreate();
    socket.UdpBind(MCAST_ADDR,MCAST_PORT);
    char sss[256];
    char fromip[16];
    while (1) {
        memset(sss, 0, 256);
        socket.UdpRecv(sss,256,fromip);
        aaa = true;
        log("recv:%s ip:%s",sss,fromip);
        serverIp = fromip;
        std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    }
//    socket.Close();
    
}

void HelloWorld::client(){
//    log("client");
    std::thread tServer(&HelloWorld::tcpServer,this);
    tServer.detach();
    SOCKET s;
    sockaddr_in mcast_addr;
    s = socket(AF_INET, SOCK_DGRAM, 0);
    if (s==-1) {
        log("error");
        return;
    }
    memset(&mcast_addr, 0, sizeof(mcast_addr));
    mcast_addr.sin_family = AF_INET;
    mcast_addr.sin_addr.s_addr = inet_addr(MCAST_ADDR);
    mcast_addr.sin_port = htons(MCAST_PORT);
    
    do {
        int n = sendto(s, MCAST_DATA, sizeof(MCAST_DATA), 0, (struct sockaddr *)&mcast_addr, sizeof(mcast_addr));
        if (n<0) {
            log("send error");
            return;
        }
//        log("send ok");
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
    } while (1);
    close(s);
//    if (sss[0] != '\0') {
    
//    }
}

void HelloWorld::addRoomJoin(){
    MenuItemFont *rj = MenuItemFont::create("加入游戏", CC_CALLBACK_0(HelloWorld::roomJoin, this));
    Menu *menu = Menu::create(rj, NULL);
    menu->setPosition(600,240);
    menu->setTag(11);
    addChild(menu);
}

void HelloWorld::roomJoin(){
    log("roomJoin!");
    std::thread tClient(&HelloWorld::tcpClient,this);
    tClient.detach();
}

void HelloWorld::tcpServer(){
    log("Tcpserver");
    ODSocket ods;
    ods.Init();
    ods.Create(AF_INET, SOCK_STREAM);
    ods.Bind(3303);
    ods.Listen(10);
//    ODSocket client_fd;
    char fromip[16];
    while (1) {
        ods.Accept(client_fd,fromip);
        char buff[256];
        client_fd.Recv(buff, 256);
        log("%s",buff);
        
        log("server--fromip:%s",fromip);
        client_fd.Send("welcome to here!", 256);
    }
    log("server close!");
    client_fd.Close();
}

void HelloWorld::tcpClient(){
    log("client:%s",serverIp);
    ODSocket ods;
    ods.Init();
    ods.Create(AF_INET, SOCK_STREAM);
    ods.Connect(serverIp, 3303);
    ods.Send("this is a client!", 256);
    char buff[256];
    while (1) {
        memset(buff, 0, 256);
        ods.Recv(buff, 256);
        log("%s",buff);
        std::this_thread::sleep_for(std::chrono::microseconds(1000));
    }
    
    ods.Close();
}






